CUDA_VISIBLE_DEVICES=2 python tools/train.py configs/recognition/mmhco/mmhco.py --seed 0 --deterministic --work-dir work_dirs/mmhco_train
