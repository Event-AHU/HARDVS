CUDA_VISIBLE_DEVICES=4,5,6,7 bash ./tools/dist_train.sh configs/recognition/mmhco/mmhco.py 4 \
--seed 0 --deterministic