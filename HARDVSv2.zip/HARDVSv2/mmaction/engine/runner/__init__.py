# Copyright (c) OpenMMLab. All rights reserved.
from .multi_loop import MultiLoaderEpochBasedTrainLoop

__all__ = ['MultiLoaderEpochBasedTrainLoop']
