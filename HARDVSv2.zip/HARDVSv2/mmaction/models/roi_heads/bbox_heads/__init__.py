# Copyright (c) OpenMMLab. All rights reserved.
from .bbox_head import BBoxHeadAVA

__all__ = ['BBoxHeadAVA']
