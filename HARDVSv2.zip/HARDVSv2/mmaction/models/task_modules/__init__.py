# Copyright (c) OpenMMLab. All rights reserved.
from .assigners import MaxIoUAssignerAVA

__all__ = ['MaxIoUAssignerAVA']
