# Copyright (c) OpenMMLab. All rights reserved.
from .max_iou_assigner_ava import MaxIoUAssignerAVA

__all__ = ['MaxIoUAssignerAVA']
