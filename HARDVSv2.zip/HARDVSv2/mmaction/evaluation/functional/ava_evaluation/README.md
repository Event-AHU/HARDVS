The code under this folder is from the official [ActivityNet repo](https://github.com/activitynet/ActivityNet).
Some unused codes are removed to minimize the length of codes added.
